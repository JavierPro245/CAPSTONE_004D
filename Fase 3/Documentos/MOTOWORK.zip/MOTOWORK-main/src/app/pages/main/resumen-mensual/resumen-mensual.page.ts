import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resumen-mensual',
  templateUrl: './resumen-mensual.page.html',
  styleUrls: ['./resumen-mensual.page.scss'],
})
export class ResumenMensualPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
