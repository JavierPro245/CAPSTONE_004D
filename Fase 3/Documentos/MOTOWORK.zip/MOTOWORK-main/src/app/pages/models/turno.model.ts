export interface Turno {
    uidTurno: string;
    uidEmployee: string;
    descripcion: string;
    HoraIngreso: string;
    HoraSalida: string;
    fecha: Date;
    img: string;
} 