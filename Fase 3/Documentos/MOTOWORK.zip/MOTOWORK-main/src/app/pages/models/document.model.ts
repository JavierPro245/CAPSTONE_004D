export interface Document {
    uidDoc: string;
    uidEmployee: string;
    descripcion: string;
    tipo: string;
    estado: string;
    fecha: Date;
    archivo: string;
} 