export interface User {
    uid: string;
    name: string;
    email: string;
    password: string;
    rol: string;
    img: string;
}