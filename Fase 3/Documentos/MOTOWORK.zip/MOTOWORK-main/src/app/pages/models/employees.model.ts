export interface Employees {
    uid: number;
    name: string;
    email: string;
    password: string;
    role: string;
    img: string;
}