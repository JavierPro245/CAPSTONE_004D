import { Injectable } from '@angular/core';
import { ActionPerformed, PushNotificationSchema, PushNotifications, Token } from '@capacitor/push-notifications';
@Injectable({
  providedIn: 'root'
})
export class NotificationsService {

  constructor() { }
}
